﻿namespace Pudelwohl_Hotel_and_Resort_Management_Suite_Ultimate_Wuff_Wuff.Helpers
{
    public interface IHasId
    {
        public int Id { get; }
    }
}
