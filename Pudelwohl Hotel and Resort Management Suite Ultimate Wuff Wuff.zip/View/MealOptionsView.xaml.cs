﻿using System.Windows.Controls;

namespace Pudelwohl_Hotel_and_Resort_Management_Suite_Ultimate_Wuff_Wuff.View
{
    public partial class MealOptionsView : UserControl
    {
        public MealOptionsView()
        {
            InitializeComponent();
        }
    }
}
